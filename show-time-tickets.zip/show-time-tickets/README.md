# Show-Time-Tickets

## Overview
The application helps the users to eliminate the efforts to go to the movie theatre for purchasing tickets. This application will book the movie ticket online based upon user preferences. In this, we have a Home screen where the latest movies will be displayed, Login screen which includes users to register and log in with their credentials, a facility to select the available seats in the theatre and a simple payment method screen which allows user to select from different types of payment methods.

Project Documentation: 

[Project Documentation](https://github.com/naveenpi/show-time-tickets/blob/master/Documentation/Project%20Documentation.doc)

ER Diagram:

[ER diagram](https://github.com/naveenpi/show-time-tickets/blob/master/Documentation/ERdiagram.pdf)
