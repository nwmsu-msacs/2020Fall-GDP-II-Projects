package com.example.showtime;

public class Utils {

    //This is your from email
    public static final String EMAIL = "gdpteam2@gmail.com";

    //This is your from email password
    public static final String PASSWORD = "Gdpteam-02";
}
