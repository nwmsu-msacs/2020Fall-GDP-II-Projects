# Ecommerce webapp for grocery shopping

This project is to develop an e-commerce web application to users for grocery shopping. Due to current pandemic situtation across the world, many customers do not prefer to buy groceries by visiting any grocery stores. This web application will act as a virtual store which enables the customers to buy groceries online. The users can also choose to either pick up their order from the store or get it delivered directly to their homes.

## Team members and their roles:
1. Deepak Malempati - Project Manager, Developer
1. Omkar Abhiteja Badda - QA Engineer (Testing)
1. Sushmita Rudra - Developer
1. Kamal Reddy Donthireddy - Developer
1. Gangadhar Yerramsetti - DB Administrator

## Github links of Team members:

1. Deepak Malempati : https://github.com/Deepakmalempati
1. Omkar Abhiteja Badda - https://github.com/abhiteja29
1. Sushmita Rudra - https://github.com/Sushmita-Rudra
1. Kamal Reddy Donthireddy - https://github.com/Kamal4195
1. Gangadhar Yerramsetti - https://github.com/gangadhary574
