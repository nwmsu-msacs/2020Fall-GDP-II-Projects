'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class OrderMedicine extends Model {
}

module.exports = OrderMedicine
