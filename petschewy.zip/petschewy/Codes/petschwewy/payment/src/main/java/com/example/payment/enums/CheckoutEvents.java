
package com.example.payment.enums;


public enum CheckoutEvents {
    AUTHORIZE,
    CANCEL,
    CLOSE,
    PAYMENTTYPESELECTION,
    CARDTYPERESOLVE
}
