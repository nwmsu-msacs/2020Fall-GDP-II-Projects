package com.example.petsandroid;

public class Utils {

    //This is your from email
    public static final String EMAIL = "myarts741@gmail.com";

    //This is your from email password
    public static final String PASSWORD = "sudhasoma3456";


}
