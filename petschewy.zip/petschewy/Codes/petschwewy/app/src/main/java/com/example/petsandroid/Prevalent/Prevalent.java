package com.example.petsandroid.Prevalent;


import com.example.petsandroid.Model.Users;

public class Prevalent
{
    public static Users currentOnlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}
