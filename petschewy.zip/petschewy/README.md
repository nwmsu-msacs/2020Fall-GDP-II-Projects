# PetsChewy
The prime objective of this project is to develop a general purpose e-commerce store where products for pets like food, and their toys can be bought from the comfort of home through the Internet. An online store is a virtual store on the Internet where customers can browse the category and select products of interest. The selected items may be collected in a shopping cart. At checkout time, the items in the shopping cart will be presented as an order. At that time, more information will be needed to complete the transaction. Usually, the customer will be asked to fill or select a billing address, a shipping address, a shipping option, and payment information such as credit card number. An e-mail notification is sent to the customer as soon as the order is placed.

## Team members Names:
1. Priyanka Bodapati                                                                                           
1. Deepthi Tejaswani Chokka
1. Sushma Yedugani
1. Suma Soma
1. Nikitha Kethireddy

## Team Members GitHub profile links:
1. https://github.com/pinky407
1. https://github.com/Deepthi1003
1. https://github.com/sushma95
1. https://github.com/suma-gitrep
1. https://github.com/nikithakethireddy1996

## Team Members Images
<img src="https://github.com/suma-gitrep/petschewy/blob/master/Priyanka.jpg" width="170" height="250"/> <img src="https://github.com/suma-gitrep/petschewy/blob/master/Deepthi.jpeg" width="170" height="250"/> <img src="https://github.com/suma-gitrep/petschewy/blob/master/sushma.jpeg" width="170" height="250"/> <img src="https://github.com/suma-gitrep/petschewy/blob/master/suma.jpeg" width="170" height="250"/> <img src="https://github.com/suma-gitrep/petschewy/blob/master/Nikitha.jpg" width="170" height="250"/>




 
