# BearcatJobSearch

Bearcat Job Search is a web application used by northwest students to register and apply jobs.

## Developers
1. [Anil Bomma](https://github.com/anil-bomma)
1. [Prasanna kumar Potnuru](https://github.com/prasu93)
1. [Yugandhar Mamidi](https://github.com/yugandharmamidi)
1. [Santhosh kumar Bollena](https://github.com/santhoshkumarbollena)
1. [Sai Chandu Gampa](https://github.com/saichandugampa)
1. [Mahender reddy surkanti](https://github.com/Mahender1166)
