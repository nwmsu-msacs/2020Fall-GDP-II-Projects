// vue.config.js
module.exports = {
  transpileDependencies: ["@adonisjs/websocket-client/index"],
  publicPath: '/bearcat-job-search-ui/dist'
};