module.exports = {
  presets: ["@vue/app"],
  plugins: [
    "@babel/plugin-transform-runtime",
    "@babel/plugin-transform-regenerator",
  ],
};
