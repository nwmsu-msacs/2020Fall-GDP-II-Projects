<template>
  <div>
    <slot name="nav"></slot>
    <slot name="content"></slot>
  </div>
</template>
