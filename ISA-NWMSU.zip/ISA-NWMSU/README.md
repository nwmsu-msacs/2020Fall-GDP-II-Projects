# Indian Student Asssociation - NWMSU

## Team Members:
1. Bharat Reddy Male
1. Bhavya Deepthi Gorrepati
1. Maha Lakshmi Kongari
1. Sai Jyothsna Mathi
1. Dheeraj Edupuganti
1. Jeevan Reddy Mure

## About ISA:

Indian Students Association (ISA) is a recognized organization in the university. It is headed by Sai Narne.

This association works towards fulfilling the needs of Indian Students at Northwest Missouri State University. We conduct different events and programs to promote Indian Culture and make students feel at home.

## *Mockup of Home Screen:*

![ISA_Home](/Documentation/Assets/Home_latest.jpg "Philadelphia's Magic Gardens")

## *ER Diagram:*

![ER_Diagram](/Documentation/Assets/ER_Diagram_picture.png "ER Diagram")

These are only mock-ups and are subject to change during the actual implementation of the application.