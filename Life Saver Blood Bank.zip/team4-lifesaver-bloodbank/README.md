## Project Name
Life Saver Bloodbank


## Team Members
1. Venkata Hareesh Bhuma
2. Venkata Siva Krishna Mohan Pratapa
3. Raghunandan Kumar Naishadam
4. Sumanth Gorantla
5. Venkat Prudhvi Dommaraju


## Project Purpose
The purpose of our application is to let the users who are in need of emergency for blood can login to the Life Saver Blood Bank application and can request the donors for blood. Once the request is placed by the users based on the availability of the blood group.

