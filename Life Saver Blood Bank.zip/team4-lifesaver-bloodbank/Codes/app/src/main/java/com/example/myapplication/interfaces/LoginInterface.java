package com.example.myapplication.interfaces;


public interface LoginInterface {

    public void postLogin();
}
