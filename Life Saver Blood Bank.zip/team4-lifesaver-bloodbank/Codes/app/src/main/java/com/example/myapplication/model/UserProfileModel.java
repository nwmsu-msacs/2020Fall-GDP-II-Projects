package com.example.myapplication.model;

public class UserProfileModel {

    String userId,userfirstName,userlastName,userfullName,userEmail,userPassword,UserActivationNumber,userCreatedOn,userUpdatedOn,userStatus;

    String userMasterId,userDOB,userGender,userBloodGroup,userHowoften,userWeight,userLastDonation,userResPhone,userMobile,userAddress,userState,userDistrict,userCity,userinfoCreatedOn,userinfoUpdatedOn,userinfoStatus;

    public String getUserMasterId() {
        return userMasterId;
    }

    public void setUserMasterId(String userMasterId) {
        this.userMasterId = userMasterId;
    }

    public String getUserDOB() {
        return userDOB;
    }

    public void setUserDOB(String userDOB) {
        this.userDOB = userDOB;
    }

    public String getUserGender() {
        return userGender;
    }

    public void setUserGender(String userGender) {
        this.userGender = userGender;
    }

    public String getUserBloodGroup() {
        return userBloodGroup;
    }

    public void setUserBloodGroup(String userBloodGroup) {
        this.userBloodGroup = userBloodGroup;
    }

    public String getUserHowoften() {
        return userHowoften;
    }

    public void setUserHowoften(String userHowoften) {
        this.userHowoften = userHowoften;
    }

    public String getUserWeight() {
        return userWeight;
    }

    public void setUserWeight(String userWeight) {
        this.userWeight = userWeight;
    }

    public String getUserLastDonation() {
        return userLastDonation;
    }

    public void setUserLastDonation(String userLastDonation) {
        this.userLastDonation = userLastDonation;
    }

    public String getUserResPhone() {
        return userResPhone;
    }

    public void setUserResPhone(String userResPhone) {
        this.userResPhone = userResPhone;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public String getUserState() {
        return userState;
    }

    public void setUserState(String userState) {
        this.userState = userState;
    }

    public String getUserDistrict() {
        return userDistrict;
    }

    public void setUserDistrict(String userDistrict) {
        this.userDistrict = userDistrict;
    }

    public String getUserCity() {
        return userCity;
    }

    public void setUserCity(String userCity) {
        this.userCity = userCity;
    }

    public String getUserinfoCreatedOn() {
        return userinfoCreatedOn;
    }

    public void setUserinfoCreatedOn(String userinfoCreatedOn) {
        this.userinfoCreatedOn = userinfoCreatedOn;
    }

    public String getUserinfoUpdatedOn() {
        return userinfoUpdatedOn;
    }

    public void setUserinfoUpdatedOn(String userinfoUpdatedOn) {
        this.userinfoUpdatedOn = userinfoUpdatedOn;
    }

    public String getUserinfoStatus() {
        return userinfoStatus;
    }

    public void setUserinfoStatus(String userinfoStatus) {
        this.userinfoStatus = userinfoStatus;
    }

    //////////////////////////
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserfirstName() {
        return userfirstName;
    }

    public void setUserfirstName(String userfirstName) {
        this.userfirstName = userfirstName;
    }

    public String getUserlastName() {
        return userlastName;
    }

    public void setUserlastName(String userlastName) {
        this.userlastName = userlastName;
    }

    public String getUserfullName() {
        return userfullName;
    }

    public void setUserfullName(String userfullName) {
        this.userfullName = userfullName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserActivationNumber() {
        return UserActivationNumber;
    }

    public void setUserActivationNumber(String userActivationNumber) {
        UserActivationNumber = userActivationNumber;
    }

    public String getUserCreatedOn() {
        return userCreatedOn;
    }

    public void setUserCreatedOn(String userCreatedOn) {
        this.userCreatedOn = userCreatedOn;
    }

    public String getUserUpdatedOn() {
        return userUpdatedOn;
    }

    public void setUserUpdatedOn(String userUpdatedOn) {
        this.userUpdatedOn = userUpdatedOn;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }
}
